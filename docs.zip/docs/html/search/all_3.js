var searchData=
[
  ['ddepth_0',['dDepth',['../structRovAuxControl.html#ab9bc9d864d149667802b27016bedbf7d',1,'RovAuxControl']]],
  ['depth_1',['depth',['../structRovTelemetry.html#a846b9c228701e158e68998324170d419',1,'RovTelemetry']]],
  ['directions_2',['directions',['../structJoystick.html#a4fdb75f5536b6b482d58fbf5be640426',1,'Joystick']]],
  ['dpitch_3',['dPitch',['../structRovAuxControl.html#ac79d2684ff24257927185eda14a22cc2',1,'RovAuxControl']]],
  ['droll_4',['dRoll',['../structRovAuxControl.html#a7b65ccd11361537eaf456f97eb0de4ae',1,'RovAuxControl']]],
  ['dyaw_5',['dYaw',['../structRovAuxControl.html#a3260e2aa9621a3276fd0308569a1cbb5',1,'RovAuxControl']]]
];
