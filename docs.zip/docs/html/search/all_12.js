var searchData=
[
  ['write_0',['write',['../classRovCommunication.html#a97dc1141f89ab5a37116fb7c6ef06535',1,'RovCommunication']]]
];
