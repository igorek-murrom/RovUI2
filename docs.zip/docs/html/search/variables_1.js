var searchData=
[
  ['baseasf_0',['baseASF',['../structJoystick.html#ac7fc71d6710626ae048852cc1ac15ede',1,'Joystick']]],
  ['buttons_1',['buttons',['../structJoystick.html#a27dd88366262a78e4421855110b2a49d',1,'Joystick']]],
  ['buttons_5fid_2',['buttons_id',['../structJoystick.html#aefc92127d5f3b364767df689505c4aef',1,'Joystick']]]
];
