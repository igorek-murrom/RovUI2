var searchData=
[
  ['pitch_0',['pitch',['../structRovTelemetry.html#a61f12b161cde2e92e699b8d41ef75e6b',1,'RovTelemetry']]]
];
