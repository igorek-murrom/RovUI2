var searchData=
[
  ['temperature_0',['temperature',['../structRovTelemetry.html#a8c929cc898a454a9b23261b268eff578',1,'RovTelemetry']]],
  ['thrusterpower_1',['thrusterPower',['../structRovControl.html#acd45218a0ed7c9e367c423a62a2c5ebb',1,'RovControl']]]
];
