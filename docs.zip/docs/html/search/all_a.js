var searchData=
[
  ['numaxes_0',['numAxes',['../structJoystick.html#afe95dc0c1b151bc3e75510688db9b649',1,'Joystick']]],
  ['numbuttons_1',['numButtons',['../structJoystick.html#a76db666f694659e9a1a796c77c90ef05',1,'Joystick']]],
  ['numhats_2',['numHats',['../structJoystick.html#aa655fd237049e6814e25d5d152c13dff',1,'Joystick']]]
];
