var searchData=
[
  ['mainwindow_0',['MainWindow',['../classMainWindow.html',1,'MainWindow'],['../classMainWindow.html#a996c5a2b6f77944776856f08ec30858d',1,'MainWindow::MainWindow()']]],
  ['manipulatoropenclose_1',['manipulatorOpenClose',['../structRovControl.html#a06580abcaba3715de61b967be557cd8b',1,'RovControl']]],
  ['manipulatorrotate_2',['manipulatorRotate',['../structRovControl.html#a71c36df9868f8ff51391f7c205e3ff58',1,'RovControl']]],
  ['maxsamples_3',['maxSamples',['../classContinousDataSplineChart.html#ab21f52cb4c72fd89ae9cafb1d2221eae',1,'ContinousDataSplineChart']]],
  ['millis_4',['millis',['../structRovHeartBeat.html#a940e3706d773fad67bfcf9939e520253',1,'RovHeartBeat']]]
];
