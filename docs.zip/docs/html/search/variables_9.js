var searchData=
[
  ['roll_0',['roll',['../structRovTelemetry.html#a9d6ba8fb9f9eebc4a38bd6c112839154',1,'RovTelemetry']]],
  ['runtimeasf_1',['runtimeASF',['../structJoystick.html#a503eab4e09d4de1928d90cc6a896ed5f',1,'Joystick']]]
];
