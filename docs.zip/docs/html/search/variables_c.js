var searchData=
[
  ['version_0',['version',['../structRovControl.html#af62f287d216cc4120a5b80fc74fae341',1,'RovControl::version()'],['../structRovTelemetry.html#af6650c2a4e71d611541dbbf0bca7248b',1,'RovTelemetry::version()']]],
  ['voltage_1',['voltage',['../structRovTelemetry.html#ace2cc005a04713db5759642d2f4f322b',1,'RovTelemetry']]]
];
